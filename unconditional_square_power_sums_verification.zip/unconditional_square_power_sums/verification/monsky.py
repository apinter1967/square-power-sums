"""Monsky's matrices over F_2: exact rank-zero obstruction."""
import math

def legendre_bit(a,p):
    x=pow(a%p,(p-1)//2,p)
    assert x in (1,p-1)
    return int(x==p-1)

def gf2rank(M):
    if not M:return 0
    rows=[sum(x<<j for j,x in enumerate(row)) for row in M]
    r=0
    for j in range(len(M[0])):
        piv=next((i for i in range(r,len(rows)) if rows[i]>>j&1),None)
        if piv is None:continue
        rows[r],rows[piv]=rows[piv],rows[r]
        for i in range(len(rows)):
            if i!=r and rows[i]>>j&1:rows[i]^=rows[r]
        r+=1
    return r

def certificate(n,primes):
    pp=sorted(p for p in primes if p!=2 and n%p==0)
    assert math.prod(pp)*(2 if n%2==0 else 1)==n
    t=len(pp)
    A=[[0 if i==j else legendre_bit(q,p) for j,q in enumerate(pp)] for i,p in enumerate(pp)]
    for i in range(t):A[i][i]=sum(A[i])%2
    d2=[legendre_bit(2,p) for p in pp]
    dm=[legendre_bit(-1,p) for p in pp]
    M=[[0]*(2*t) for _ in range(2*t)]
    for i in range(t):
        for j in range(t):
            diag=int(i==j)
            M[i][j]=diag*d2[i]
            M[i][j+t]=A[i][j]^(diag*d2[i])
            if n%2==0:
                M[i+t][j]=A[j][i]^(diag*d2[i])
                M[i+t][j+t]=diag*dm[i]
            else:
                M[i+t][j]=A[i][j]^(diag*(d2[i]^dm[i]))
                M[i+t][j+t]=diag*d2[i]
    rank=gf2rank(M)
    return {'n':str(n),'odd_primes':list(map(str,pp)),'matrix':M,'rank_F2':rank,'pure_selmer_dimension':2*t-rank}
