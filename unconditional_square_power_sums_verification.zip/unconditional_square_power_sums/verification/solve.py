"""Certified continued-fraction Pell units and Arb Baker--Davenport reduction.

The step limit is a resource limit, NEVER a mathematical stopping criterion.
An unfinished continued fraction produces an explicit unresolved record.
"""
import math
from flint import arb,ctx,fmpz
import sympy as sp

ctx.prec=256
CACHE={}
LIMIT=200000

def issquare(n):
    return n>=0 and math.isqrt(n)**2==n

def fundamental(D,limit=LIMIT):
    if D in CACHE:return CACHE[D]
    a0=math.isqrt(D)
    if a0*a0==D:raise ValueError('square Pell parameter')
    m=0;den=1;a=a0;period=[]
    for i in range(limit):
        m=den*a-m;den=(D-m*m)//den;a=(a0+m)//den
        period.append(a)
        if a==2*a0:break
    else:
        result={'status':'unresolved','D':str(D),'iterations':limit}
        CACHE[D]=result;return result
    ell=len(period);length=ell if ell%2==0 else 2*ell
    pm2=fmpz(0);pm1=fmpz(1);qm2=fmpz(1);qm1=fmpz(0)
    for i in range(length):
        ai=a0 if i==0 else period[(i-1)%ell]
        p=ai*pm1+pm2;q=ai*qm1+qm2
        pm2,pm1=pm1,p;qm2,qm1=qm1,q
    assert p*p-D*q*q==1
    result={'status':'certified','D':str(D),'period_length':ell,'T':str(p),'U':str(q)}
    CACHE[D]=result;return result

def uniq_int(x):
    n=x.unique_fmpz()
    if n is None:raise ArithmeticError('insufficient interval precision')
    return int(n)

def ceilint(x):return uniq_int(x.ceil())

def norm(x):
    r=uniq_int((x+arb(1)/2).floor())
    return abs(x-r)

def bd(unit1,unit2):
    def unitlog(unit):
        if 'T' in unit:return (arb(unit['T'])+arb(unit['U'])*arb(unit['D']).sqrt()).log()
        return arb(unit['log_eta_interval'])
    L1=unitlog(unit1)
    L2=unitlog(unit2)
    # Rounded-up Matveev constant: 10^14 L1 L2 (1+log max(r,s)).
    # r < 3+K(1+log r+log H), K=10^14 ceil(L2), H=1+ceil(L1).
    K=10**14*ceilint(L2);H=1+ceilint(L1)
    J=ceilint(arb(4*K*H).log());initial=4*K*J
    M=initial;records=[]
    tau=L1/L2;mu=arb(2).log()/L2;A=8/L2
    for round_id in range(5):
        if M<=0:break
        z=tau;pm2,pm1=0,1;qm2,qm1=1,0
        found=False
        for j in range(400):
            t=uniq_int(z.floor());p=t*pm1+pm2;q=t*qm1+qm2
            if q>6*M:
                eps=norm(q*mu)-M*abs(q*tau-p)
                if eps>0:
                    upper=(A*q/eps).log()/L1
                    newM=max(0,ceilint(upper))
                    records.append({'M':str(M),'p':str(p),'q':str(q),'epsilon_interval':str(eps),'upper_interval':str(upper),'new_M':newM})
                    found=True;break
            z=1/(z-t);pm2,pm1=pm1,p;qm2,qm1=qm1,q
        if not found:raise ArithmeticError('no positive epsilon')
        if newM>=M:break
        M=newM
    return {'initial_M':str(initial),'r_bound':M,'log_eta_interval':str(L1),'log_theta_interval':str(L2),'precision_bits':ctx.prec,'rounds':records}

def powersum(k,x):
    ans=sp.Rational(0)
    # Horner's rule, coefficient B_1=-1/2.
    for i in range(k+1,-1,-1):
        ans=ans*x+sp.binomial(k+1,i)*sp.bernoulli(k+1-i,0)/(k+1)
    assert ans.q==1
    return int(ans)

def solve_triple(a,b,c):
    base={'a':str(a),'b':str(b),'c':str(c)}
    D1=a*c;D2=2*b*c
    if issquare(D1) or issquare(D2):
        return {**base,'status':'excluded_square_parameter','solutions':[]}
    if issquare(D1*D2):
        assert a==2 and b==1
        return {**base,'status':'excluded_equal_fields','solutions':[]}
    u1=fundamental(D1);u2=fundamental(D2)
    if u1['status']!='certified' or u2['status']!='certified':
        return {**base,'status':'unresolved_units','D1':str(D1),'D2':str(D2)}
    for prec in (256,512,1024):
        ctx.prec=prec
        try:reduction=bd(u1,u2);break
        except ArithmeticError:continue
    else:return {**base,'status':'unresolved_reduction','D1':str(D1),'D2':str(D2)}
    T=int(u1['T']);U=int(u1['U']);tr=1;ur=0;sol=[]
    for r in range(1,reduction['r_bound']+1):
        tr,ur=T*tr+D1*U*ur,U*tr+T*ur
        if (tr+1)%(2*a) or (tr-1)%(2*c):continue
        us=(tr+1)//(2*a);ws=(tr-1)//(2*c)
        if not ws or not issquare(us) or not issquare(ws):continue
        if (2*c*ws+1)%b:continue
        vs=(2*c*ws+1)//b
        if not issquare(vs):continue
        u,w,v=math.isqrt(us),math.isqrt(ws),math.isqrt(vs)
        assert a*u*u-c*w*w==1 and b*v*v-2*c*w*w==1
        sol.append({'r':r,'u':str(u),'v':str(v),'w':str(w),'x':str(a*u*u)})
    return {**base,'status':'solved','D1':str(D1),'D2':str(D2),'reduction':reduction,'solutions':sol}
