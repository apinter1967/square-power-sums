"""Exact local sieve for even power sums. No global-solubility claim."""
import itertools, json, math, time, sys
from pathlib import Path
import sympy as sp
from cypari2 import Pari

pari=Pari()

def bits(n):
    while n:
        t=n&-n; yield t.bit_length()-1; n-=t

def factor(n):
    f={int(p):int(e) for p,e in sp.factorint(abs(n)).items()}
    assert math.prod(p**e for p,e in f.items())==abs(n)
    for p in f: assert pari(p).isprime()==1
    return f

def residues(k,m):
    # S_k has period m^2 modulo m, by grouping into m blocks of m.
    Q=m*m
    sq={i*i%Q for i in range(Q)}
    sqm={i*i%m for i in range(m)}
    good=0; S=0
    for x in range(Q):
        if S in sqm: good|=1<<x
        S=(S+pow(x,k,m))%m
    assert S==0
    aa=[];cc=[];bb=[]
    for r in range(Q):
        vals={r*t%Q for t in sq}
        aa.append(sum(1<<x for x in vals)&good)
        cc.append(sum(1<<((x+1)%Q) for x in vals)&good)
        bb.append(sum(1<<x for x in range(Q) if (2*x-1)%Q in vals)&good)
    return Q,aa,cc,bb

def val(r,p):
    if not r:return 10**9
    n,d=int(r.p),int(r.q);v=0
    while n%p==0:n//=p;v+=1
    while d%p==0:d//=p;v-=1
    return v

def unit_char(r,p):
    n,d=int(r.p),int(r.q)
    while n%p==0:n//=p
    while d%p==0:d//=p
    return int(pow((n%p)*pow(d,-1,p)%p,(p-1)//2,p)==p-1)

def run(k,mods=(16,9,5,7,11,13)):
    start=time.monotonic()
    B=sp.bernoulli(k)
    facB=factor(int(B.p)); facD=factor(int(B.q)); facM=factor(2**(k-1)-1)
    A=sorted(set(facB)|set(facD))
    C=sorted((set(A)|set(facM))-{2})
    P=[2]+C; L=len(P); pos={p:i for i,p in enumerate(P)}
    amask=sum(1<<pos[p] for p in A); cmask=(1<<L)-2
    neg=[0]*L; minus=[0]*L; two=[0]*L
    for j,p in enumerate(P[1:],1):
        minus[j]=int(p%4==3)
        two[j]=int(p%8 in (3,5))
        for i,r in enumerate(P):
            if r!=p and pow(r,(p-1)//2,p)==p-1: neg[j]|=1<<i
    c0=[sp.binomial(k+1,i)*sp.bernoulli(k+1-i,0)/(k+1) for i in range(k+2)]
    ch=[sp.binomial(k+1,i)*sp.bernoulli(k+1-i,sp.Rational(1,2))/((k+1)*2**i) for i in range(k+2)]
    rules=[]
    for coeff in (c0,ch):
        rule={}
        for j,p in enumerate(P[1:],1):
            s=val(coeff[1],p)
            if all(i-1+val(coeff[i],p)>s for i in range(2,k+2)):
                rule[j]=(s,unit_char(coeff[1],p))
        rules.append(rule)
    def square_local(mask,rule):
        for j in bits(mask&~1):
            if j not in rule:continue
            s,t=rule[j]
            if s%2==0 or ((mask&neg[j]).bit_count()&1)!=t:return False
        return True
    vals={0:1}
    def value(mask):
        if mask not in vals:
            low=mask&-mask
            vals[mask]=P[low.bit_length()-1]*value(mask-low)
        return vals[mask]
    local=[residues(k,m) for m in mods]
    Ac=[pos[p] for p in A]
    pair_count=0; hilbert_pairs=0; triple_count=0; survivors=[]
    # The two norm equations are locally soluble at every prime in a*c.
    for assignments in itertools.product(range(3),repeat=len(Ac)):
        ma=mc=0
        for j,s in zip(Ac,assignments):
            if s==1:ma|=1<<j
            elif s==2:mc|=1<<j
        pair_count+=1
        if not square_local(ma,rules[0]) or not square_local(mc,rules[0]):continue
        if any(((mc&neg[j]).bit_count()&1)!=minus[j] for j in bits(ma&~1)):continue
        if any((ma&neg[j]).bit_count()&1 for j in bits(mc&~1)):continue
        a=value(ma);c=value(mc)
        pair_local=[aa[a%Q]&cc[c%Q] for Q,aa,cc,bb in local]
        if not all(pair_local):continue
        hilbert_pairs+=1
        allowed=[]
        for j in bits(cmask&~(ma|mc)):
            if ((ma&neg[j]).bit_count()&1)!=two[j]:continue
            if ((mc&neg[j]).bit_count()&1)!=(minus[j]^two[j]):continue
            allowed.append(j)
        for s in range(1<<len(allowed)):
            mb=sum(1<<j for i,j in enumerate(allowed) if s>>i&1)
            if not square_local(mb,rules[1]):continue
            if any(((mb&neg[j]).bit_count()&1)!=minus[j] for j in bits(ma&~1)):continue
            if any((mb&neg[j]).bit_count()&1 for j in bits(mc&~1)):continue
            triple_count+=1
            b=value(mb)
            if not all(pl&bb[b%Q] for pl,(Q,aa,cc,bb) in zip(pair_local,local)):continue
            survivors.append([str(a),str(b),str(c)])
    elapsed=time.monotonic()-start
    result={'k':k,'bernoulli':str(B),'numerator_factors':facB,'denominator_factors':facD,'mersenne_factors':facM,
      'A':A,'C':C,'moduli_S':list(mods),'pair_count':pair_count,'pair_survivors':hilbert_pairs,
      'derivative_rules':[{str(P[j]):list(v) for j,v in r.items()} for r in rules],
      'triple_pre_final_local':triple_count,'survivor_count':len(survivors),'survivors':survivors,
      'elapsed_seconds':elapsed,'status':'local_sieve_only'}
    Path(f'sieve_{k}.json').write_text(json.dumps(result,indent=2))
    print(k,'A',len(A),'C',len(C),'pairs',pair_count,'local pairs',hilbert_pairs,'triples',triple_count,'survivors',len(survivors),'seconds',round(elapsed,3),flush=True)
    print('first',survivors[:15],flush=True)
    return result

if __name__=='__main__':
    for k in map(int,sys.argv[1:]):run(k)
