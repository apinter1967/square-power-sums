"""Uniform valuation constraints at the three rational roots.

Unlike a fixed-depth congruence sieve, this excludes a residue class whose
arbitrarily deep lifts would all have the wrong valuation parity.
"""
import json,math,time
from pathlib import Path
import numpy as np
import sympy as sp

def check(k, triples, p, rules):
    e=4 if p==2 else (3 if p<=13 else 2)
    m=p**e;Q=m*p if k%(p-1)==0 else m
    sq=np.zeros(Q,dtype=bool)
    for j in range(Q):sq[j*j%Q]=True
    sqm={j*j%m for j in range(m)};good=np.zeros(Q,dtype=bool);S=0
    for x in range(Q):
        good[x]=S in sqm;S=(S+pow(x,k,m))%m
    assert S==0
    xs=np.arange(Q,dtype=np.int64);res=np.flatnonzero(sq);cache={}
    def cl(d):
        d%=Q
        if d not in cache:
            z=np.zeros(Q,dtype=bool);z[(res*d)%Q]=True;cache[d]=z
        return cache[d]
    out=[];ex=[]
    s0=rules[0].get(str(p));sh=rules[1].get(str(p))
    for a,b,c in triples:
        ok=good & cl(a) & cl(c)[(xs-1)%Q] & cl(b)[(2*xs-1)%Q]
        if p==2:
            if a%2 and c%2:ok[:]=False
        else:
            if s0 and s0[0]%2:
                if a%p:ok &= xs%p!=0
                if c%p:ok &= xs%p!=1
            if sh and sh[0]%2 and b%p:ok &= (2*xs-1)%p!=0
        (out if np.any(ok) else ex).append((a,b,c))
    return out,ex

