"""Fresh, unconditional verification for even 60 <= k <= 78.

Recomputes Bernoulli factorizations, all initial triples and uniform local
tests. Uses only three compact units, each checked by exact principal-ideal
cancellation and a rational nonsquareness test. All remaining CF periods,
logarithmic bounds and finite enumerations are recomputed.
"""
import json,sys,time,math,hashlib,platform
from importlib.metadata import version
import numpy as np
import flint
from pathlib import Path
from cypari2 import Pari
import sympy as sp
import sieve,valuation_sieve,solve,monsky,compact_filter

if not __debug__:
    raise RuntimeError("Verification requires assertions: do not run Python with -O.")
sys.set_int_max_str_digits(0)
pari=Pari();pari.allocatemem(256*1024*1024,2*1024*1024*1024)
UNIT_CERTS={}
COMPACT_D={15342935387542798535232818,46028806162628395605698454,4592133311438467125812759190}
RANK_N={73803512604521151251718239144420316906,
95309618632060696201528912654738165054580193614922,
347015917053850282797668513319330,92725502057293235383410,
7054216993604157779821216794732638879084599218861210,
5538229830684513732053525469968535435679185045906,
204914503735327008085980442388835811120129846698522,
1376460240979179948283404039953380599847117527485624804209866}
TRACE_TESTS={(2,1920527523685803,1):(10567201,132090)}

def trace_obstruction(a,b,c,p,m):
    D=a*c
    assert p>2 and pari(p).isprime()==1 and b%p==0 and D%p!=0
    assert m>0 and m%4!=0
    unit=solve.fundamental(D);assert unit['status']=='certified'
    residue=compact_filter.power((int(unit['T'])%p,int(unit['U'])%p),m,D,p)
    assert residue==(1,0)
    # A zero trace of eta^r would make eta^r an element of order four.
    # Its order also divides m, which is not divisible by four.
    return {'D':str(D),'prime':p,'annihilating_exponent':m,'unit':unit,
            'power_residue':list(residue),'reason':'no power has zero trace modulo p'}

def verify_unit(D):
    if D in UNIT_CERTS:return UNIT_CERTS[D]
    raw=(Path('compact_units')/f'{D}.json').read_bytes();rec=json.loads(raw)
    assert int(rec['D'])==D
    nf=pari.nfinit(pari(f'x^2-{D}'));valuations={};primes=set()
    for A,B,e in rec['factors']:
        e=int(e)
        if not e:continue
        fac=pari.idealfactor(nf,pari(f'({A})+({B})*x'))
        for i in range(fac.nrows()):
            ideal=fac[i,0];primes.add(int(ideal[0]));key=str(pari.idealhnf(nf,ideal))
            valuations[key]=valuations.get(key,0)+e*int(fac[i,1])
    assert all(v==0 for v in valuations.values())
    assert all(pari(p).isprime()==1 for p in primes)
    rows,parity=compact_filter.prepare(rec)
    assert parity['norm_sign']==1 and parity['mod_squares_is_nonsquare']
    cert={'D':str(D),'factors':len(rec['factors']),'prime_ideals':len(valuations),'all_ideal_valuations_zero':True,'parity':parity,'sha256':hashlib.sha256(raw).hexdigest()}
    UNIT_CERTS[D]=(rec,cert)
    return rec,cert

def run(k):
    start=time.monotonic();src=sieve.run(k);triples=[tuple(map(int,r)) for r in src['survivors']]
    exclusions=[]
    primes=sorted({2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73}|{p for p in src['A']+src['C'] if p<=200})
    for p in primes:
        triples,ex=valuation_sieve.check(k,triples,p,src['derivative_rules'])
        exclusions.extend({'triple':[str(v) for v in r],'prime':p} for r in ex)
    branches=[];original=set()
    for a,b,c in triples:
        D=a*c;n=a*b*c;base={'a':str(a),'b':str(b),'c':str(c)}
        if n in RANK_N:
            matrix=monsky.certificate(n,sorted(set(src['A'])|set(src['C'])))
            if matrix['pure_selmer_dimension']==0:
                branches.append({**base,'method':'Monsky matrix','certificate':matrix})
            else:
                ranks=[int(z) for z in pari.ellrank(pari.ellinit([0,0,0,-n*n,0]),0)[:3]]
                assert ranks[1]==0
                branches.append({**base,'method':'PARI 2-descent','rank_bounds':ranks,'Monsky_certificate':matrix})
        elif (a,b,c) in TRACE_TESTS:
            p,m=TRACE_TESTS[(a,b,c)]
            branches.append({**base,'method':'finite-order trace obstruction',
                             'certificate':trace_obstruction(a,b,c,p,m)})
        elif D in COMPACT_D:
            unit,_=verify_unit(D)
            if b==3:
                rows,parity=compact_filter.prepare(unit);V,chi=compact_filter.unitmod(rows,D,3,parity['power_to_Pell_order'])
                assert chi==-1 and compact_filter.mul(V,V,D,3)==(1,0)
                branches.append({**base,'method':'compact unit, no zero trace modulo 3','unit_D':str(D),'residue_mod_3':list(V)})
            else:
                assert b==1
                cert=compact_filter.test(k,a,b,c,unit);assert cert is not None
                branches.append({**base,'method':'compact unit and quartic index','certificate':cert})
        else:
            result=solve.solve_triple(a,b,c);assert result['status']=='solved',result
            for sol in result['solutions']:
                x=int(sol['x']);value=solve.powersum(k,x);is_square=solve.issquare(value)
                sol['original_is_square']=is_square
                if is_square:original.add((x,math.isqrt(value)))
                else:
                    for p in sp.primerange(3,1000):
                        s=sum(pow(j,k,p) for j in range(1,x))%p
                        if s not in {j*j%p for j in range(p)}:
                            sol['power_sum_obstruction']={'prime':int(p),'residue':int(s)};break
            branches.append({**base,'method':'Pell and Baker-Davenport','certificate':result})
    assert original=={(2,1)}
    counts={m:sum(r['method']==m for r in branches) for m in sorted({r['method'] for r in branches})}
    out={'k':k,'initial_local_branches':len(src['survivors']),'uniform_local_exclusions':len(exclusions),'remaining_branches':len(triples),'local_exclusions':exclusions,'branches':branches,'method_counts':counts,'positive_solutions':[[2,1]],'complete':True,'elapsed_seconds':time.monotonic()-start}
    print('CERTIFIED',k,'remaining after uniform sieve',len(triples),'methods',counts,'seconds',round(out['elapsed_seconds'],3),flush=True)
    return out

if __name__=='__main__':
    st=time.monotonic();results=[run(k) for k in range(60,80,2)]
    result={'theorem':'For each even k from 60 through 78, S_k(x)=sum(j^k,j=1..x-1)=y^2 has exactly the positive solution (x,y)=(2,1).','conditional_assumptions':[],'cases':results,'fundamental_units':list(solve.CACHE.values()),'compact_unit_certificates':[v[1] for v in UNIT_CERTS.values()],'total_seconds':time.monotonic()-st,'python':sys.version,'platform':platform.platform(),'sympy':sp.__version__,'numpy':np.__version__,'python_flint':flint.__version__,'cypari2':version('cypari2'),'PARI':str(pari.version())}
    Path('certificate.json').write_text(json.dumps(result,indent=2))
    print('ALL TEN CASES CERTIFIED, seconds',round(result['total_seconds'],3),flush=True)
