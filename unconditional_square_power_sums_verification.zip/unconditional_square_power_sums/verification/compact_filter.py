"""Exact sign, square-class and residue tests for compact quadratic units.

The caller first certifies ideal cancellation. All units in this certificate
have norm +1 and are nonsquares, so their cubes are odd powers of the
fundamental norm-one unit. No fundamentalness assumption is used.
"""
import json, math, sys
from fractions import Fraction as F
from pathlib import Path
import sympy as sp
from quartic_filter import mul,power

sys.set_int_max_str_digits(0)

def sqrat(z):
    if z<0:return False
    return math.isqrt(z.numerator)**2==z.numerator and math.isqrt(z.denominator)**2==z.denominator

def field_square(A,B,D):
    if not B:return sqrat(A) or sqrat(A/D)
    norm=A*A-D*B*B
    if not sqrat(norm):return False
    rt=F(math.isqrt(norm.numerator),math.isqrt(norm.denominator))
    return any(q>0 and sqrat(q) for q in [(A+rt)/2,(A-rt)/2])

def sign_embedding(A,B,D):
    if not B:return 1 if A>0 else -1
    if not A:return 1 if B>0 else -1
    if A>0 and B>0:return 1
    if A<0 and B<0:return -1
    return (1 if A>0 else -1)*(1 if A*A>D*B*B else -1)

def prepare(record):
    D=int(record['D']);rows=[(F(a),F(b),int(e)) for a,b,e in record['factors']]
    sign=1;norm_sign=1
    for A,B,e in rows:
        if e%2:
            sign*=sign_embedding(A,B,D);norm_sign*=1 if A*A-D*B*B>0 else -1
    if sign<0:rows.append((F(-1),F(0),1))
    A,B=F(1),F(0)
    for C,E,e in rows:
        if e%2:A,B=A*C+D*B*E,A*E+B*C
    nonsquare=not field_square(A,B,D)
    assert norm_sign==-1 or nonsquare
    # A norm -1 unit already has odd exponent. For norm +1 use nonsquareness.
    exponent=6 if norm_sign==-1 else 3
    return rows,{'norm_sign':norm_sign,'positive_embedding':True,'mod_squares_is_nonsquare':nonsquare,'power_to_Pell_order':exponent}

def val(n,p):
    if not n:return 10**9
    v=0
    while n%p==0:n//=p;v+=1
    return v

def unitmod(rows,D,p,exponent):
    chi=1 if pow(D%p,(p-1)//2,p)==1 else -1
    if chi==1:
        r=int(sp.sqrt_mod(D,p));z=1;total=0
        for a,b,e in rows:
            d=math.lcm(a.denominator,b.denominator);A=int(a*d);B=int(b*d)
            N=A*A-D*B*B;nv=val(N,p);R=r;M=p
            for _ in range(nv):
                R+=((D-R*R)//M*pow(2*R,-1,p)%p)*M;M*=p
            num=A+B*R;v=val(num,p);dv=val(d,p)
            assert v<=nv
            un=(num//p**v)*pow(d//p**dv,-1,p)%p
            total+=(v-dv)*e;z=z*pow(un,e,p)%p
        assert total==0
        z=pow(z,exponent,p)
        return ((z+pow(z,-1,p))*pow(2,-1,p)%p,(z-pow(z,-1,p))*pow(2*r,-1,p)%p),chi
    z=(1,0);total=0
    for a,b,e in rows:
        d=math.lcm(a.denominator,b.denominator);A=int(a*d);B=int(b*d)
        v=min(val(A,p),val(B,p));dv=val(d,p)
        unit=(A//p**v*pow(d//p**dv,-1,p)%p,B//p**v*pow(d//p**dv,-1,p)%p)
        total+=(v-dv)*e;z=mul(z,power(unit,e%(p*p-1),D,p),D,p)
    assert total==0
    return power(z,exponent,D,p),chi

def candidate_traces(V,D,p,chi):
    N=p-chi
    # Enumerate the norm-one group exactly; accept eta iff V is an odd power of eta.
    sqroot={j*j%p:j for j in range(p)}
    group=[]
    invD=pow(D,-1,p)
    for T in range(p):
        u2=(T*T-1)*invD%p
        if u2 not in sqroot:continue
        U=sqroot[u2];group.append((T,U))
        if U:group.append((T,(-U)%p))
    assert len(group)==N
    factors=list(sp.factorint(N))
    generator=next(z for z in group if all(power(z,N//q,D,p)!=(1,0) for q in factors))
    powers=[];z=(1,0)
    for j in range(N):powers.append(z);z=mul(z,generator,D,p)
    e=powers.index(V)
    return [z[0] for j,z in enumerate(powers) if (e-j)%math.gcd(2*j,N)==0]

def test(k,a,b,c,record):
    assert b==1
    D=a*c;rows,parity=prepare(record);index=2 if a==1 else 1
    for p in list(sp.primerange(3,200))+[257,65537]:
        p=int(p)
        if D%p==0:continue
        V,chi=unitmod(rows,D,p,parity['power_to_Pell_order'])
        traces=candidate_traces(V,D,p,chi)
        sq={j*j%p for j in range(p)};allowed=[]
        aset={a*t%p for t in sq};cset={c*t%p for t in sq}
        # Use power-sum residues modulo p only when p itself is a period.
        S=[0]*p;cur=0
        for x in range(p):S[x]=cur;cur=(cur+pow(x,k,p))%p
        periodic=cur==0
        for T in traces:
            Z=T if index==1 else (2*T*T-1)%p
            if Z not in sq:continue
            x=(Z+1)*pow(2,-1,p)%p
            if x not in aset:continue
            if (x-1)%p not in cset:continue
            if periodic and S[x] not in sq:continue
            allowed.append(T)
        if not allowed:
            return {'unit_D':str(D),'odd_index_certificate':parity,'quartic_index':index,'prime':p,'unit_residue':list(V),'chi_D':chi,'candidate_trace_count':len(traces),'power_sum_period_p':periodic}
    return None

