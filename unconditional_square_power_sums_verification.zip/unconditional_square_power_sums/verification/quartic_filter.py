"""Exact arithmetic in quadratic residue algebras."""
def mul(x,y,D,m):return ((x[0]*y[0]+D*x[1]*y[1])%m,(x[0]*y[1]+x[1]*y[0])%m)
def power(x,n,D,m):
    z=(1,0)
    while n:
        if n&1:z=mul(z,x,D,m)
        x=mul(x,x,D,m);n//=2
    return z

