"""Reproduce the partial k=80 calculation; one branch is deliberately open.

This is not part of the theorem verifier. No resource limit or missing
unit certificate is used to exclude the unresolved branch.
"""
import json,math,time
from pathlib import Path
import verify

start=time.monotonic();k=80
src=verify.sieve.run(k)
triples=[tuple(map(int,t)) for t in src['survivors']]
primes=sorted({2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73}
              |{p for p in src['A']+src['C'] if p<=200})
for p in primes:
    triples,_=verify.valuation_sieve.check(k,triples,p,src['derivative_rules'])
d=351399254696254837299710032223990163729557511854938623630
records=[];pending=[];solutions=set()
for a,b,c in triples:
    base={'a':str(a),'b':str(b),'c':str(c)}
    if (a,b,c)==(1,1,d):
        matrix=verify.monsky.certificate(d,sorted(set(src['A'])|set(src['C'])))
        assert matrix['pure_selmer_dimension']==1
        pending.append({**base,'status':'unresolved','Monsky_certificate':matrix,
                        'reason':'fundamental-unit certificate not supplied'})
    elif (a,b,c)==(2,475226488251803312715,5009593):
        cert=verify.trace_obstruction(a,b,c,5,2)
        records.append({**base,'method':'finite-order trace obstruction','certificate':cert})
    else:
        r=verify.solve.solve_triple(a,b,c)
        assert r['status']=='solved',r
        for sol in r['solutions']:
            x=int(sol['x']);S=verify.solve.powersum(k,x)
            sol['original_is_square']=verify.solve.issquare(S)
            if sol['original_is_square']:solutions.add((x,math.isqrt(S)))
        records.append({**base,'method':'Pell and Baker-Davenport','certificate':r})
assert len(triples)==7 and len(records)==6 and len(pending)==1
assert solutions=={(2,1)}
result={'k':80,'complete':False,'initial_sieve_branches':len(src['survivors']),
        'uniform_sieve_branches':len(triples),'closed_branches':records,
        'unresolved_branches':pending,'solutions_in_closed_branches':sorted(solutions),
        'elapsed_seconds':time.monotonic()-start}
Path('remark_80.json').write_text(json.dumps(result,indent=2))
print('K=80: SIX BRANCHES CLOSED; ONE BRANCH REMAINS OPEN',flush=True)
